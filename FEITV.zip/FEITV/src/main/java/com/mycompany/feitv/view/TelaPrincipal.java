package com.mycompany.feitv.view;

/**
 * @author Cliente
 */

import com.mycompany.feitv.controller.ListaController;
import com.mycompany.feitv.controller.UsuarioController;
import com.mycompany.feitv.controller.VideoController;
import com.mycompany.feitv.model.ListaReproducao;
import com.mycompany.feitv.model.SerieFilme;
import com.mycompany.feitv.model.Usuario;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

public class TelaPrincipal extends javax.swing.JFrame {

    private Usuario usuario = new Usuario(0, "Cliente", "cliente@teste.com", "");
    private VideoController videoController = new VideoController();
    private ListaController listaController = new ListaController();
    private UsuarioController usuarioController = new UsuarioController();

    private DefaultListModel<SerieFilme> videosModel;
    private DefaultListModel<ListaReproducao> playlistsModel;
    private DefaultListModel<SerieFilme> playlistVideosModel;

    
    public TelaPrincipal() {
        initComponents();
        inicializarModelos();
    }

    public void setDados(Usuario usuario, UsuarioController usuarioController,
                         VideoController videoController, ListaController listaController) {
        if (usuario != null) {
            this.usuario = usuario;
        }
        if (usuarioController != null) {
            this.usuarioController = usuarioController;
        }
        if (videoController != null) {
            this.videoController = videoController;
        }
        if (listaController != null) {
            this.listaController = listaController;
        }
        iniciarTela();
    }

    private void iniciarTela() {
        carregarVideos("");
        carregarPlaylists();
        atualizarPerfil();
    }


    private void inicializarModelos() {
        videosModel = new DefaultListModel<>();
        lstVideos.setModel(videosModel);
        playlistsModel = new DefaultListModel<>();
        lstPlaylists.setModel(playlistsModel);
        playlistVideosModel = new DefaultListModel<>();
        lstVideosPlaylist.setModel(playlistVideosModel);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    //GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        panelBusca = new javax.swing.JPanel();
        txtBusca = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        lstVideos = new javax.swing.JList<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDetalhes = new javax.swing.JTextArea();
        btnCurtir = new javax.swing.JButton();
        btnDescurtir = new javax.swing.JButton();
        lblPlaylist = new javax.swing.JLabel();
        cmbPlaylists = new javax.swing.JComboBox<>();
        btnAdicionarPlaylist = new javax.swing.JButton();
        panelFavoritos = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        lstPlaylists = new javax.swing.JList<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        lstVideosPlaylist = new javax.swing.JList<>();
        btnCriarPlaylist = new javax.swing.JButton();
        btnRenomearPlaylist = new javax.swing.JButton();
        btnExcluirPlaylist = new javax.swing.JButton();
        btnRemoverVideo = new javax.swing.JButton();
        panelPerfil = new javax.swing.JPanel();
        lblPerfilTitulo = new javax.swing.JLabel();
        lblNome = new javax.swing.JLabel();
        lblEmail = new javax.swing.JLabel();
        lblTotalUsuarios = new javax.swing.JLabel();
        lblTotalVideos = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("FEItv");
        setPreferredSize(new java.awt.Dimension(1000, 660));

        txtBusca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });
        txtDetalhes.setEditable(false);
        txtDetalhes.setLineWrap(true);
        txtDetalhes.setWrapStyleWord(true);
        jScrollPane1.setViewportView(lstVideos);
        jScrollPane2.setViewportView(txtDetalhes);
        lstVideos.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                lstVideosValueChanged(evt);
            }
        });
        btnCurtir.setText("Curtir");
        btnCurtir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCurtirActionPerformed(evt);
            }
        });
        btnDescurtir.setText("Descurtir");
        btnDescurtir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDescurtirActionPerformed(evt);
            }
        });
        lblPlaylist.setText("Lista de reprodução:");
        btnAdicionarPlaylist.setText("Adicionar");
        btnAdicionarPlaylist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarPlaylistActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBuscaLayout = new javax.swing.GroupLayout(panelBusca);
        panelBusca.setLayout(panelBuscaLayout);
        panelBuscaLayout.setHorizontalGroup(
            panelBuscaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBuscaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelBuscaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBuscaLayout.createSequentialGroup()
                        .addComponent(txtBusca, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(8, 8, 8)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1)
                    .addComponent(jScrollPane2)
                    .addGroup(panelBuscaLayout.createSequentialGroup()
                        .addComponent(btnCurtir)
                        .addGap(8, 8, 8)
                        .addComponent(btnDescurtir)
                        .addGap(8, 8, 8)
                        .addComponent(lblPlaylist)
                        .addGap(8, 8, 8)
                        .addComponent(cmbPlaylists, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(8, 8, 8)
                        .addComponent(btnAdicionarPlaylist)))
                .addContainerGap())
        );
        panelBuscaLayout.setVerticalGroup(
            panelBuscaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBuscaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelBuscaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBusca, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(8, 8, 8)
                .addGroup(panelBuscaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCurtir, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDescurtir, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPlaylist)
                    .addComponent(cmbPlaylists, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAdicionarPlaylist, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Buscar vídeos", panelBusca);

        jScrollPane3.setViewportView(lstPlaylists);
        lstPlaylists.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                lstPlaylistsValueChanged(evt);
            }
        });
        jScrollPane4.setViewportView(lstVideosPlaylist);
        btnCriarPlaylist.setText("Criar lista");
        btnCriarPlaylist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCriarPlaylistActionPerformed(evt);
            }
        });
        btnRenomearPlaylist.setText("Renomear lista");
        btnRenomearPlaylist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRenomearPlaylistActionPerformed(evt);
            }
        });
        btnExcluirPlaylist.setText("Excluir lista");
        btnExcluirPlaylist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExcluirPlaylistActionPerformed(evt);
            }
        });
        btnRemoverVideo.setText("Remover vídeo");
        btnRemoverVideo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverVideoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelFavoritosLayout = new javax.swing.GroupLayout(panelFavoritos);
        panelFavoritos.setLayout(panelFavoritosLayout);
        panelFavoritosLayout.setHorizontalGroup(
            panelFavoritosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFavoritosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelFavoritosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelFavoritosLayout.createSequentialGroup()
                        .addComponent(btnCriarPlaylist)
                        .addGap(8, 8, 8)
                        .addComponent(btnRenomearPlaylist)
                        .addGap(8, 8, 8)
                        .addComponent(btnExcluirPlaylist)))
                .addGap(10, 10, 10)
                .addGroup(panelFavoritosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnRemoverVideo))
                .addContainerGap())
        );
        panelFavoritosLayout.setVerticalGroup(
            panelFavoritosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFavoritosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelFavoritosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(8, 8, 8)
                .addGroup(panelFavoritosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCriarPlaylist, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRenomearPlaylist, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluirPlaylist, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRemoverVideo, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Lista de reprodução", panelFavoritos);

        lblPerfilTitulo.setText("Meu Perfil");
        lblNome.setText("Nome:");
        lblEmail.setText("E-mail:");
        lblTotalUsuarios.setText("Total de usuários:");
        lblTotalVideos.setText("Total de vídeos:");
        javax.swing.GroupLayout panelPerfilLayout = new javax.swing.GroupLayout(panelPerfil);
        panelPerfil.setLayout(panelPerfilLayout);
        panelPerfilLayout.setHorizontalGroup(
            panelPerfilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPerfilLayout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addGroup(panelPerfilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblPerfilTitulo)
                    .addComponent(lblNome)
                    .addComponent(lblEmail)
                    .addComponent(lblTotalUsuarios)
                    .addComponent(lblTotalVideos))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        panelPerfilLayout.setVerticalGroup(
            panelPerfilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPerfilLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(lblPerfilTitulo)
                .addGap(16, 16, 16)
                .addComponent(lblNome)
                .addGap(12, 12, 12)
                .addComponent(lblEmail)
                .addGap(12, 12, 12)
                .addComponent(lblTotalUsuarios)
                .addGap(12, 12, 12)
                .addComponent(lblTotalVideos)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Perfil", panelPerfil);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }//GEN-END:initComponents
    // </editor-fold>

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {
        carregarVideos(txtBusca.getText());
    }

    private void lstVideosValueChanged(javax.swing.event.ListSelectionEvent evt) {
        if (evt.getValueIsAdjusting()) return;
        SerieFilme video = lstVideos.getSelectedValue();
        if (video != null) {
            txtDetalhes.setText(
                "Titulo: " + video.getTitulo() + "\n" +
                "Tipo: " + video.getTipo() + "\n" +
                "Ano: " + video.getAno() + "\n" +
                "Categoria: " + video.getCategoria() + "\n" +
                "Detalhe: " + video.getDetalhe() + "\n" +
                "Likes: " + video.getLikes() + "\n" +
                "Dislikes: " + video.getDislikes() + "\n\n" +
                "Descricao:\n" + video.getDescricao()
            );
        }
    }

    private void btnCurtirActionPerformed(java.awt.event.ActionEvent evt) {
        SerieFilme video = lstVideos.getSelectedValue();
        if (video == null) return;
        videoController.curtir(usuario.getId(), video.getId());
        carregarVideos(txtBusca.getText());
    }

    private void btnDescurtirActionPerformed(java.awt.event.ActionEvent evt) {
        SerieFilme video = lstVideos.getSelectedValue();
        if (video == null) return;
        videoController.descurtir(usuario.getId(), video.getId());
        carregarVideos(txtBusca.getText());
    }

    private void btnAdicionarPlaylistActionPerformed(java.awt.event.ActionEvent evt) {
        SerieFilme video = lstVideos.getSelectedValue();
        ListaReproducao lista = (ListaReproducao) cmbPlaylists.getSelectedItem();
        if (video == null || lista == null) return;
        listaController.adicionarVideo(lista.getId(), video.getId());
        carregarVideosDaPlaylist();
    }

    private void lstPlaylistsValueChanged(javax.swing.event.ListSelectionEvent evt) {
        if (!evt.getValueIsAdjusting()) carregarVideosDaPlaylist();
    }

    private void btnCriarPlaylistActionPerformed(java.awt.event.ActionEvent evt) {
        String nome = javax.swing.JOptionPane.showInputDialog(this, "Nome da lista de reprodução:");
        if (nome == null) return;
        listaController.criar(usuario.getId(), nome);
        carregarPlaylists();
    }

    private void btnRenomearPlaylistActionPerformed(java.awt.event.ActionEvent evt) {
        ListaReproducao lista = lstPlaylists.getSelectedValue();
        if (lista == null) return;
        String novoNome = javax.swing.JOptionPane.showInputDialog(this, "Novo nome da lista:", lista.getNome());
        if (novoNome == null) return;
        listaController.renomear(lista.getId(), novoNome);
        carregarPlaylists();
    }

    private void btnExcluirPlaylistActionPerformed(java.awt.event.ActionEvent evt) {
        ListaReproducao lista = lstPlaylists.getSelectedValue();
        if (lista == null) return;
        listaController.excluir(lista.getId());
        carregarPlaylists();
        playlistVideosModel.clear();
    }

    private void btnRemoverVideoActionPerformed(java.awt.event.ActionEvent evt) {
        ListaReproducao lista = lstPlaylists.getSelectedValue();
        SerieFilme video = lstVideosPlaylist.getSelectedValue();
        if (lista == null || video == null) return;
        listaController.removerVideo(lista.getId(), video.getId());
        carregarVideosDaPlaylist();
    }

    private void carregarVideos(String termo) {
        videosModel.clear();
        List<SerieFilme> videos = videoController.listar(termo);
        for (SerieFilme v : videos) videosModel.addElement(v);
        if (!videosModel.isEmpty()) lstVideos.setSelectedIndex(0);
        else txtDetalhes.setText("");
    }

    private void carregarPlaylists() {
        playlistsModel.clear();
        List<ListaReproducao> playlists = listaController.listarDoUsuario(usuario.getId());
        DefaultComboBoxModel<ListaReproducao> comboModel = new DefaultComboBoxModel<>();
        for (ListaReproducao l : playlists) {
            playlistsModel.addElement(l);
            comboModel.addElement(l);
        }
        cmbPlaylists.setModel(comboModel);
        if (!playlistsModel.isEmpty()) lstPlaylists.setSelectedIndex(0);
    }

    private void carregarVideosDaPlaylist() {
        playlistVideosModel.clear();
        ListaReproducao lista = lstPlaylists.getSelectedValue();
        if (lista == null) return;
        List<SerieFilme> videos = listaController.listarVideos(lista.getId());
        for (SerieFilme v : videos) playlistVideosModel.addElement(v);
    }

    private void atualizarPerfil() {
        setTitle("FEItv - " + usuario.getNome());
        configurarBordas();
        lblNome.setText("Nome: " + usuario.getNome());
        lblEmail.setText("E-mail: " + usuario.getEmail());
        lblTotalUsuarios.setText("Total de usuários: " + usuarioController.totalUsuarios());
        lblTotalVideos.setText("Total de vídeos: " + videoController.totalVideos());
    }

    private void configurarBordas() {
        javax.swing.border.TitledBorder bordaBusca = javax.swing.BorderFactory.createTitledBorder("Buscar vídeos");
        javax.swing.border.TitledBorder bordaLista = javax.swing.BorderFactory.createTitledBorder("Lista de reprodução");
        javax.swing.border.TitledBorder bordaPerfil = javax.swing.BorderFactory.createTitledBorder("Perfil");
        panelBusca.setBorder(bordaBusca);
        panelFavoritos.setBorder(bordaLista);
        panelPerfil.setBorder(bordaPerfil);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel panelBusca;
    private javax.swing.JTextField txtBusca;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<SerieFilme> lstVideos;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea txtDetalhes;
    private javax.swing.JButton btnCurtir;
    private javax.swing.JButton btnDescurtir;
    private javax.swing.JLabel lblPlaylist;
    private javax.swing.JComboBox<ListaReproducao> cmbPlaylists;
    private javax.swing.JButton btnAdicionarPlaylist;
    private javax.swing.JPanel panelFavoritos;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JList<ListaReproducao> lstPlaylists;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JList<SerieFilme> lstVideosPlaylist;
    private javax.swing.JButton btnCriarPlaylist;
    private javax.swing.JButton btnRenomearPlaylist;
    private javax.swing.JButton btnExcluirPlaylist;
    private javax.swing.JButton btnRemoverVideo;
    private javax.swing.JPanel panelPerfil;
    private javax.swing.JLabel lblPerfilTitulo;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblTotalUsuarios;
    private javax.swing.JLabel lblTotalVideos;
    // End of variables declaration//GEN-END:variables


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaPrincipal().setVisible(true);
            }
        });
    }

}
